# Security Policy

## Reporting a Vulnerability

See our [Vulnerability Disclosure Policy](https://getodk.org/legal/vulnerability.html).
