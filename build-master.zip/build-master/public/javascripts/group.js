// GROUPS SHOULD HAVE LABELS

/*
repeats:
•    loop X times
•    jr:template="" means the repeat exists no matter what (so you're not prompted about it) (instance) [always include]
•    jr:noAddRemove="true()" (supposedly) means that it won't prompt whether users want more (control)
•    jr:count specifies either a specific number or an xpath to another field (control)
*/


// GROUPS don't necessarily have a instance.
